<?php return array (
  'App\\Providers\\EventServiceProvider' => 
  array (
  ),
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
  ),
);