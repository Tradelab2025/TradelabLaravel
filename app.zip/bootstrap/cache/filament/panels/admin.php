<?php return array (
  'livewireComponents' => 
  array (
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
  ),
  'pageDirectories' => 
  array (
  ),
  'pageNamespaces' => 
  array (
  ),
  'resources' => 
  array (
  ),
  'resourceDirectories' => 
  array (
  ),
  'resourceNamespaces' => 
  array (
  ),
  'widgets' => 
  array (
  ),
  'widgetDirectories' => 
  array (
  ),
  'widgetNamespaces' => 
  array (
  ),
);